package break_out.model;

/**
 * This object contains information about the running game
 * 
 *@author dmlux
 *@author I. Schumacher
 *
 *modified by
 *@author Stefan Scheunemann 674685
 *@author Eric Neuwald 675477
 *@Gruppe 165
 */

public class Level extends Thread {
	

    /**
     * The game to which the level belongs 
     */
    private Game game;
	 
    /**
   	 * The number of the level
   	 */
    private int levelnr;
       
    /**
	 * The score of the level
	 */
    private int score;
    
    /**
     * Ball wird in Level benoetigt
     */
    private Ball ball;
    
    /**
     * Paddle wird in Level benoetigt
     */
    private Paddle paddle;
    
    
    
    /**
     * Flag that shows if the ball was started
     */
    private boolean ballWasStarted = false;		//Ball soll Anfangs sich nicht bewegen

        
    /**
     * Der Konstruktor instanziiert einen neuen Level:
     * @param game Das zugehoerige Game-Objekt
     * @param levelnr Die Nummer des zu instanziierenden Levels
     * @param score Der bisher erreichte Scorewert
     * @param ball Position und Veraenderungen des Balls
     * @param paddle Instantziierung des Paddles, welches auf dem Spielfeld liegt
     */
    public Level(Game game, int levelnr, int score) {
    	this.game = game;
    	this.levelnr = levelnr;
    	this.score = score;
        loadLevelData(levelnr);
        this.ball = new Ball();
        this.paddle = new Paddle();
    }

    
    /**
     * Setzt ballWasStarted auf true, d.h. der Ball "startet", 
     * weil so die bedingten Anweisungen in der while-Schleife der run-Methode ausgefuehrt werden.
     */
    public void startBall() {
        ballWasStarted = true;
    }

    /**
     * Setzt ballWasStarted auf false, d.h. der Ball "pausiert", weil so die bedingten Anweisungen in der while-Schleife 
     * der run-Methode nicht ausgefuehrt werden.
     */
    public void stopBall() {
        ballWasStarted = false;
    }
    
    /**
     * Liefert den booleschen Wert der Variablen ballWasStarted
     * @return ballWasStarted True, wenn sich der Ball bewegt, sonst false
     */
    public boolean ballWasStarted() {
        return ballWasStarted;
    }
    
    /**
     * Methode wird verwendet, um auf das Objekt Ball zugreifen zu koennen, wird in der Klasse Field benoetigt
     * @return ball
     */
    public Ball getBall() {
    	return this.ball;
    }
    
    /**
     * getter fuer Paddle, wird in der Klasse Field benoetigt
     * @return paddle
     */
    public Paddle getPaddle() {
    	return this.paddle;
    }
    

    /**
     * Diese Methode enthaelt die Threadlogik, d.h. hier wird festgelegt, was im Thread ablaeuft.
     */
    public void run() {	
    	
    	game.notifyObservers();
    		
    	// Endlosschleife fuer den Ablauf
    	while (true) {
    		// wenn ballWasStarted wahr ist (d.h. der Ball soll sich bewegen)
	        if (ballWasStarted) {
	            
	        	//Aufruf der Methode reactOnBorder aus Ball, prueft auf Wandberuehrung
	        	ball.reactOnBorder();
	        	
	        	
	        	if(this.ball.hitsPaddle(paddle)) {	//Test auf Beruehrung des Balls mit Paddle
	        		this.ball.reflectOnPaddle(paddle);	//Methode zum ablenken de Balls wird aufgerufen
	        	}
	        	
	        	//Aufruf der Methode Update Position aus Ball, aktualisiert Position des Balls
	        	ball.updatePosition();
	        	
	        	//Aufruf der Methode Update Position aus Paddle, aktualisiert Position des Paddle
	        	paddle.updatePosition();
	                               
	            // Das als Observer angemeldete View-Objekt wird informiert, damit ein Neuzeichnen (repaint)
	        	// des Spielfeldes vorgenommen wird.
	            game.notifyObservers();    
	                
	        }
	        // Der Thread pausiert kurz
	        try {
	            Thread.sleep(4);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
    	}   
    }
    
    
    /**
    * Zugriff auf die der Levelnummer zugeordnete JSON-Datei
    * @param levelnr Die Nummer X fuer die LevelX.json Datei
    */
    private void loadLevelData(int levelnr) {
    		
    }
    
}
    


	
