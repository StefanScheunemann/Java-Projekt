package break_out.model;

//Konstanten werden fuer Breite und Hoehe des Spielfeldes und des Balls benoetigt
import break_out.Constants;

/**
 * Klasse Ball kontrolliert das Verhalten des Balls
 * @author Stefan Scheunemann 675686
 * @author Eric Neuwald 675477
 * Gruppe 165
 */

public class Ball {
	
	//Variablendeklaration
	private Position pos;	
	private Vector2D direction;
	private Paddle paddle;
	
	
	public Ball() {
		
		//Startposition des Balls
		this.pos = new Position(
				Constants.SCREEN_WIDTH / 2 - Constants.BALL_DIAMETER / 2,	//Position des Balls auf x-Achse
				Constants.SCREEN_HEIGHT - Constants.BALL_DIAMETER - Constants.PADDLE_HEIGHT);	//Position des Balls auf y-Achse
		
		this.direction = new Vector2D(5, -5);	//Richtungsvektor des Balls
		this.direction.rescale();				//Normalisierung der Geschwindigkeit
				
	}
	
	public void reactOnBorder( ) {
        if(pos.getX() <= 0) {			//wenn Position des Balls auf der x-Achse <= 0 ist, wird die Wand beruehrt und der Ball soll abprallen
        	pos.setX(this.getPosition().getX());
        	double dx = -direction.getDX();		//die Richtung des Balls auf der x-Achse wird invertiert
        	direction.setDX(dx);	//der invertierte Wert fuer dx wird in der Klasse Vector2D gespeichert
        }
        
        else if(pos.getX() >= Constants.SCREEN_WIDTH - Constants.BALL_DIAMETER) {		//wenn Position des Balls auf der x-Achse <= der Breite des Felds ist, wird die Wand beruehrt und der Ball soll abprallen
        	pos.setX(this.getPosition().getX() - Constants.BALL_DIAMETER);
        	double dx = -direction.getDX();		//die Richtung des Balls auf der x-Achse wird invertiert
        	direction.setDX(dx);	//der invertierte Wert fuer dx wird in der Klasse Vector2D gespeichert
        }
        
    	          
        else if(pos.getY() <= 0) {		//wenn Position des Balls auf der y-Achse <= 0 ist, wird die Wand beruehrt und der Ball soll abprallen
        	pos.setY(this.getPosition().getY());
        	double dy = -direction.getDY();		//die Richtung des Balls auf der x-Achse wird invertiert
        	direction.setDY(dy);	//der invertierte Wert fuer dy wird in der Klasse Vector2D gespeichert
        }
        
        else if(pos.getY() >= Constants.SCREEN_HEIGHT - Constants.BALL_DIAMETER) {		//wenn Position des Balls auf der y-Achse <= der Hoehe des Felds ist, wird die Wand beruehrt und der Ball soll abprallen
        	pos.setY(this.getPosition().getY() - Constants.BALL_DIAMETER);
        	double dy =  -direction.getDY();	//die Richtung des Balls auf der x-Achse wird invertiert
        	direction.setDY(dy);	//der invertierte Wert fuer dy wird in der Klasse Vector2D gespeichert
        }
	}
	
	//Kollisionsabfrage zwischen Ball und Paddle
	public boolean hitsPaddle(Paddle paddle) {		
		if(pos.getY() + Constants.BALL_DIAMETER >= paddle.getPosition().getY()) {		//Text auf Hoehe, spart Ressourcen, da selten nur auf y-Hoehe, spart Rechenressourcen
			if(pos.getX() <= paddle.getPosition().getX() + Constants.PADDLE_WIDTH && pos.getX() >= paddle.getPosition().getX() - Constants.BALL_DIAMETER) {	//Text, ob Ball auf x-Bereich des Paddle
				return true;		//gibt true zurueck, falls Paddle beruehrt
				//System.out.println("Treffer");
			}
		}
		return false;	//bei keiner Beruehrung false
	}
	
	//Methode zum Berechnen der Richtung des Balls nach Beruehrung mit Paddle
	public void reflectOnPaddle(Paddle paddle) {	
		pos.setY(paddle.getPosition().getY() - Constants.BALL_DIAMETER);	//Ball wird auf obersten Punkt des Paddle gesetzt fuer sauberes  Abprallen
		direction = new Vector2D(new Position(paddle.getPosition().getX() + (Constants.PADDLE_WIDTH / 2),	//zweiter Konstruktor aus der Klasse Vector2D wird erzeugt, erster Punkt Mitte des Paddle
				paddle.getPosition().getY() + 100),		//tiefergelegter Mittelpunkt
				new Position(pos.getX() + (Constants.BALL_DIAMETER / 2),	//x-Position des Balls
				pos.getY() + (Constants.BALL_DIAMETER / 2)));		//y-Position des Balls
		direction.rescale();	//Geschwindigkeit des Balls wird normalisiert
	}
	
	//Position des Balls wird bei Aufruf der Methode verschoben
	public void updatePosition() {
		this.pos.setPos (
			this.pos.getX() + this.direction.getDX(),	//Verschiebung auf x-Achse
			this.pos.getY() + this.direction.getDY());	//Verschiebung auf y-Achse
	}
	
	//getter fuer die Position des Balls
	public Position getPosition() {
		return this.pos;
	}
	
	//getter fuer die Richtung des Balls
	public Vector2D getDirection() {
		return this.direction;
	}
}
