package break_out.model;

import break_out.controller.JSONReader;
import break_out.Constants;

public class Stone {
	
	boolean zerstoert;
	
	JSONReader reader = new JSONReader(null);
	
	public int [][]stone = reader.getStones2DArray();
	
	int stone_width = ((int)Constants.SCREEN_WIDTH / Constants.SQUARES_X);		//TODO dynamische Steinzahl, auch in draw Methode
	int stone_height = ((int)Constants.SCREEN_HEIGHT / Constants.SQUARES_Y);

	private Position pos; {
		
    for ( int zeile = 0; zeile < stone.length; zeile++ )
    {
      for ( int spalte = 0; spalte < stone[zeile].length; spalte++ )
      
      if(stone[zeile][spalte] == 1) {
    	  
    	  this.pos = new Position(
    			  spalte * stone_width,
    			  zeile * stone_height);
      		}
      boolean zerstoert = false;
    	}
    }
	
	private void Zustand() {
		if(zerstoert == false) {
			zerstoert = true;
		}
	}
	
	public Position getPosition() {
		return this.pos;
	}
}
