package break_out.model;

import java.awt.Rectangle;
import java.util.ArrayList;

//Konstanten werden fuer Breite und Hoehe des Spielfeldes und des Balls benoetigt
import break_out.Constants;
import break_out.model.Level;

/**
 * Klasse Ball kontrolliert das Verhalten des Balls
 * @author Stefan Scheunemann 675686
 * @author Eric Neuwald 675477
 * Gruppe 165
 */

public class Ball {
	
	/**
	 * Objekts fuer Zugriff auf Position
	 */
	private Position pos;	
	
	/**
	 * Objekt fuer Zugriff auf Vector2D
	 */
	private Vector2D direction;
	
	/**
	 * Objekt fuer Zugriff auf Paddle
	 */
	private Paddle paddle;
	
	/**
	 * Objekt fuer Zugriff auf Level
	 */
	private Level level;
	
	/**
	 * Objekt fuer Rechteck um den Ball
	 */
    private Rectangle ballRectangle;
    
    /**
     * Objekt fuer Treffer an Stein
     */
    private Stone hitStone;
	
	/**
	 * Position des Balls wird gesetzt
	 * Es wird ein Rechteck um den Ball erzeugt
	 * Dem Ball wird ein Richtungsvektor gegeben
	 */
	public Ball() {

		this.pos = new Position(
				Constants.SCREEN_WIDTH / 2 - Constants.BALL_DIAMETER / 2,	//Position des Balls auf x-Achse
				Constants.SCREEN_HEIGHT - Constants.BALL_DIAMETER - Constants.PADDLE_HEIGHT);	//Position des Balls auf y-Achse
		
        ballRectangle = new Rectangle();
        ballRectangle.setFrameFromDiagonal(pos.getX(), pos.getY(),
                pos.getX() + Constants.BALL_DIAMETER, pos.getY() + Constants.BALL_DIAMETER);
		
		this.direction = new Vector2D(5, -5);	//Richtungsvektor des Balls
		this.direction.rescale();				//Normalisierung der Geschwindigkeit				
	}
	
	
	/**
	 * Kontrolliert das Apbrallen des Balls an den Seiten des Spielfeldes
	 * Ball wird bei Beruehrung mit Wand zuerst an Wand zurueckgesetzt fuer sauberes Abprallen.
	 * dx / dy kontrollieren die Bewegungsrichtung des Balls, diese werden jeweils invertiert, wenn der Ball
	 * auf ihrer Achse die Wand beruehrt. Bei Beruehrung auf x-Achse dx, bei Beruehrung auf y-Achse dy.
	 */
	public void reactOnBorder( ) {
        if(pos.getX() <= 0) {			//wenn Position des Balls auf der x-Achse <= 0 ist, wird die Wand beruehrt und der Ball soll abprallen
        	pos.setX(this.getPosition().getX());
        	double dx = -direction.getDX();		//die Richtung des Balls auf der x-Achse wird invertiert
        	direction.setDX(dx);	//der invertierte Wert fuer dx wird in der Klasse Vector2D gespeichert
        }
        
        else if(pos.getX() >= Constants.SCREEN_WIDTH - Constants.BALL_DIAMETER) {		//wenn Position des Balls auf der x-Achse <= der Breite des Felds ist, wird die Wand beruehrt und der Ball soll abprallen
        	pos.setX(this.getPosition().getX() - Constants.BALL_DIAMETER);
        	double dx = -direction.getDX();		//die Richtung des Balls auf der x-Achse wird invertiert
        	direction.setDX(dx);	//der invertierte Wert fuer dx wird in der Klasse Vector2D gespeichert
        }
        
    	          
        else if(pos.getY() <= 0) {		//wenn Position des Balls auf der y-Achse <= 0 ist, wird die Wand beruehrt und der Ball soll abprallen
        	pos.setY(this.getPosition().getY());
        	double dy = -direction.getDY();		//die Richtung des Balls auf der x-Achse wird invertiert
        	direction.setDY(dy);	//der invertierte Wert fuer dy wird in der Klasse Vector2D gespeichert
        }
        
        else if(pos.getY() >= Constants.SCREEN_HEIGHT - Constants.BALL_DIAMETER) {		//wenn Position des Balls auf der y-Achse <= der Hoehe des Felds ist, wird die Wand beruehrt und der Ball soll abprallen
        	pos.setY(this.getPosition().getY() - Constants.BALL_DIAMETER);
        	double dy =  -direction.getDY();	//die Richtung des Balls auf der x-Achse wird invertiert
        	direction.setDY(dy);	//der invertierte Wert fuer dy wird in der Klasse Vector2D gespeichert
        }
	}
	
	/**
	 * Die Methode prueft, ob der Ball das Paddle beruehrt. Dazu wird zuerst getestet, ob der Ball auf der y-Achse das Paddle beruehren kann. Ist dies nicht gegeben
	 * kann auch keine Beruehrung auf x-Achse stattfinden.
	 * Wenn auf y-Achse Beruehrung stattfindet, wird auf x-Achse geprueft, ob der Ball im Bereich des Paddle liegt.
	 * Wenn alle Bedingungen erfuellt wird true zurueckgegeben, sonst false.
	 * @param paddle Kontrolle findet am Paddle statt
	 * @return gibt bei Beruehrung von Ball an Paddle true zurueck, sonst false
	 */
	public boolean hitsPaddle(Paddle paddle) {		
		if(pos.getY() + Constants.BALL_DIAMETER >= paddle.getPosition().getY()) {		//Text auf Hoehe, spart Ressourcen, da selten nur auf y-Hoehe, spart Rechenressourcen
			if(pos.getX() <= paddle.getPosition().getX() + Constants.PADDLE_WIDTH && pos.getX() >= paddle.getPosition().getX() - Constants.BALL_DIAMETER) {	//Text, ob Ball auf x-Bereich des Paddle
				return true;		//gibt true zurueck, falls Paddle beruehrt
				//System.out.println("Treffer");
			}
		}
		return false;	//bei keiner Beruehrung false
	}
	
	/**
	 * Wenn der Ball am Paddle abprallt, soll er in einem relativen Winkel zum Paddle abprallen.
	 * Dazu muss aus der Klasse Vector2D der zweite Konstruktor aufgerufen werden, als source wird ein Punkt eingesetzt, der
	 * mittig unter dem Paddle liegt. Als target wird die Position des Mittelpunkts vom Ball verwendet.
	 * Der Konstruktor subtrahiert target von source und gibt somit einen neuen Richtungsvektor dx und dy zurueck.
	 * Am Ende muss dieser normalisiert werden, da der Ball sonst deutlich zu schnell ware.
	 * @param paddle Ball wird mit Paddle verglichen
	 */
	public void reflectOnPaddle(Paddle paddle) {	
		pos.setY(paddle.getPosition().getY() - Constants.BALL_DIAMETER);	//Ball wird auf obersten Punkt des Paddle gesetzt fuer sauberes  Abprallen
		direction = new Vector2D(new Position(paddle.getPosition().getX() + (Constants.PADDLE_WIDTH / 2),	//zweiter Konstruktor aus der Klasse Vector2D wird erzeugt, erster Punkt Mitte des Paddle
				paddle.getPosition().getY() + 50),		//tiefergelegter Mittelpunkt
				new Position(pos.getX() + (Constants.BALL_DIAMETER / 2),	//x-Position des Balls
				pos.getY() + (Constants.BALL_DIAMETER / 2)));		//y-Position des Balls
		direction.rescale();	//Geschwindigkeit des Balls wird normalisiert
	}

	/**
	 * Es wird ueberprueft, ob der Ball einen Stein beruehrt
	 * Es wird jeder Stein aus der Steinliste mit der Position des Balls verglichen, bei Kontakt wird true zurueckgegeben, sonst false
	 * @param levelStones
	 * @return true, falls Stein getroffen, sonst false
	 */
    public boolean hitsStone(ArrayList<ArrayList<Stone>>levelStones) {
        for(ArrayList<Stone> stoneList : levelStones) {
            for(Stone stone : stoneList) {
                if(stone.getState()) {
                    continue;
                }
                Rectangle stoneRectangle = stone.getRectangle();
                if(ballRectangle.intersects(stoneRectangle)) {
                    this.hitStone = stone;
                    return true;
                }
            }
        }
        return false;
    }

	/**
	 * Abprallen am Stein, bei Kontakt auf X-Achse wird dx invertiert, bei Kontakt auf Y-Achse wird dy invertiert
	 * Es wird ein bestimmter Stein aus der Steinliste uebergeben, mit dem der Ball verglichen wird
	 * Es werden die einzelnen Seiten ueberprueft, um zu ermitteln, auf welcher Seite Kontakt stattfindet mithilfe der intersect Funktion
	 * @param stone 
	 */
    public void reflectOnStone(Stone stone) {
        Rectangle stoneRectangle = stone.getRectangle();
        if(ballRectangle.getCenterX() > stoneRectangle.getMaxX()
                && ballRectangle.getCenterY() > stoneRectangle.getMinY()) {
            //Rechte Seite
            double dx = -direction.getDX();
            direction.setDX(dx);
        } else if(ballRectangle.getCenterX() > stoneRectangle.getMinX()
                && ballRectangle.getCenterY() > stoneRectangle.getMaxY()) {
            //Untere Seite
            double dy = -direction.getDY();
            direction.setDX(dy);
        } else if (ballRectangle.getCenterX() < stoneRectangle.getMinX()
                && ballRectangle.getCenterY() < stoneRectangle.getMaxY()) {
            //Linke Seite
            double dx = -direction.getDX();
            direction.setDX(dx);
        } else {
            //Oberer Seite
            double dy = -direction.getDY();
            direction.setDX(dy);
        }
    }
    
    
	/**
	 * Verschiebt bei Aufruf aktuelle Position des Ball um dx und dy
	 * und Rechteck des Balls wird um die Bewegung des Balls mitverschoben
	 */
	public void updatePosition() {
		this.pos.setPos (
			this.pos.getX() + this.direction.getDX(),	//Verschiebung auf x-Achse
			this.pos.getY() + this.direction.getDY());	//Verschiebung auf y-Achse
		
        ballRectangle.setFrameFromDiagonal(pos.getX(), pos.getY(),
                pos.getX() + Constants.BALL_DIAMETER, pos.getY() + Constants.BALL_DIAMETER);
	}
	
	/**
	 * gibt Position des Balls zurueck
	 * @return position
	 */
	public Position getPosition() {
		return this.pos;
	}
	
	/**
	 * gibt Richtungsvektor des Balls zurueck
	 * @return direction
	 */
	public Vector2D getDirection() {
		return this.direction;
	}
	
	/**
	 * gibt Postion des Rechtecks um den Ball zurueck
	 * @return ballRectangle
	 */
	public Rectangle getBallRectangle() {
		return ballRectangle;
	}
	
	/**
	 * gibt aus Liste den zuletzt getroffenen Stein wieder
	 * @return hitStone
	 */
    public Stone getLastHitStone() {
    	return hitStone;
    }
}
