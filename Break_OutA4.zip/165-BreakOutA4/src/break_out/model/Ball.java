package break_out.model;

//Konstanten werden fuer Breite und Hoehe des Spielfeldes und des Balls benoetigt
import break_out.Constants;

/**
 * Klasse Ball kontrolliert das Verhalten des Balls
 * @author Stefan Scheunemann 675686
 * @author Eric Neuwald 675477
 * Gruppe 165
 */

public class Ball {
	
	//Variablendeklaration
	private Position pos;	
	private Vector2D direction;
	private Paddle paddle;
	
	
	public Ball() {
		
		//Startposition des Balls
		this.pos = new Position(
				Constants.SCREEN_WIDTH / 2 - Constants.BALL_DIAMETER / 2,	//Position des Balls auf x-Achse
				Constants.SCREEN_HEIGHT - Constants.BALL_DIAMETER - Constants.PADDLE_HEIGHT);	//Position des Balls auf y-Achse
		
		this.direction = new Vector2D(5, -5);	//Richtungsvektor des Balls
		this.direction.rescale();				//Normalisierung der Geschwindigkeit
				
	}
	/**
	 * Kontrolliert das Apbrallen des Balls an den Seiten des Spielfeldes
	 * Ball wird bei Beruehrung mit Wand zuerst an Wand zurueckgesetzt fuer sauberes Abprallen.
	 * dx / dy kontrollieren die Bewegungsrichtung des Balls, diese werden jeweils invertiert, wenn der Ball
	 * auf ihrer Achse die Wand beruehrt. Bei Beruehrung auf x-Achse dx, bei Beruehrung auf y-Achse dy.
	 */
	public void reactOnBorder( ) {
        if(pos.getX() <= 0) {			//wenn Position des Balls auf der x-Achse <= 0 ist, wird die Wand beruehrt und der Ball soll abprallen
        	pos.setX(this.getPosition().getX());
        	double dx = -direction.getDX();		//die Richtung des Balls auf der x-Achse wird invertiert
        	direction.setDX(dx);	//der invertierte Wert fuer dx wird in der Klasse Vector2D gespeichert
        }
        
        else if(pos.getX() >= Constants.SCREEN_WIDTH - Constants.BALL_DIAMETER) {		//wenn Position des Balls auf der x-Achse <= der Breite des Felds ist, wird die Wand beruehrt und der Ball soll abprallen
        	pos.setX(this.getPosition().getX() - Constants.BALL_DIAMETER);
        	double dx = -direction.getDX();		//die Richtung des Balls auf der x-Achse wird invertiert
        	direction.setDX(dx);	//der invertierte Wert fuer dx wird in der Klasse Vector2D gespeichert
        }
        
    	          
        else if(pos.getY() <= 0) {		//wenn Position des Balls auf der y-Achse <= 0 ist, wird die Wand beruehrt und der Ball soll abprallen
        	pos.setY(this.getPosition().getY());
        	double dy = -direction.getDY();		//die Richtung des Balls auf der x-Achse wird invertiert
        	direction.setDY(dy);	//der invertierte Wert fuer dy wird in der Klasse Vector2D gespeichert
        }
        
        else if(pos.getY() >= Constants.SCREEN_HEIGHT - Constants.BALL_DIAMETER) {		//wenn Position des Balls auf der y-Achse <= der Hoehe des Felds ist, wird die Wand beruehrt und der Ball soll abprallen
        	pos.setY(this.getPosition().getY() - Constants.BALL_DIAMETER);
        	double dy =  -direction.getDY();	//die Richtung des Balls auf der x-Achse wird invertiert
        	direction.setDY(dy);	//der invertierte Wert fuer dy wird in der Klasse Vector2D gespeichert
        }
	}
	
	/**
	 * Die Methode prueft, ob der Ball das Paddle beruehrt. Dazu wird zuerst getestet, ob der Ball auf der y-Achse das Paddle beruehren kann. Ist dies nicht gegeben
	 * kann auch keine Beruehrung auf x-Achse stattfinden.
	 * Wenn auf y-Achse Beruehrung stattfindet, wird auf x-Achse geprueft, ob der Ball im Bereich des Paddle liegt.
	 * Wenn alle Bedingungen erfuellt wird true zurueckgegeben, sonst false.
	 * @param paddle Kontrolle findet am Paddle statt
	 * @return gibt bei Beruehrung von Ball an Paddle true zurueck, sonst false
	 */
	public boolean hitsPaddle(Paddle paddle) {		
		if(pos.getY() + Constants.BALL_DIAMETER >= paddle.getPosition().getY()) {		//Text auf Hoehe, spart Ressourcen, da selten nur auf y-Hoehe, spart Rechenressourcen
			if(pos.getX() <= paddle.getPosition().getX() + Constants.PADDLE_WIDTH && pos.getX() >= paddle.getPosition().getX() - Constants.BALL_DIAMETER) {	//Text, ob Ball auf x-Bereich des Paddle
				return true;		//gibt true zurueck, falls Paddle beruehrt
				//System.out.println("Treffer");
			}
		}
		return false;	//bei keiner Beruehrung false
	}
	
	/**
	 * Wenn der Ball am Paddle abprallt, soll er in einem relativen Winkel zum Paddle abprallen.
	 * Dazu muss aus der Klasse Vector2D der zweite Konstruktor aufgerufen werden, als source wird ein Punkt eingesetzt, der
	 * mittig unter dem Paddle liegt. Als target wird die Position des Mittelpunkts vom Ball verwendet.
	 * Der Konstruktor subtrahiert target von source und gibt somit einen neuen Richtungsvektor dx und dy zurueck.
	 * Am Ende muss dieser normalisiert werden, da der Ball sonst deutlich zu schnell ware.
	 * @param paddle Ball wird mit Paddle verglichen
	 */
	public void reflectOnPaddle(Paddle paddle) {	
		pos.setY(paddle.getPosition().getY() - Constants.BALL_DIAMETER);	//Ball wird auf obersten Punkt des Paddle gesetzt fuer sauberes  Abprallen
		direction = new Vector2D(new Position(paddle.getPosition().getX() + (Constants.PADDLE_WIDTH / 2),	//zweiter Konstruktor aus der Klasse Vector2D wird erzeugt, erster Punkt Mitte des Paddle
				paddle.getPosition().getY() + 50),		//tiefergelegter Mittelpunkt
				new Position(pos.getX() + (Constants.BALL_DIAMETER / 2),	//x-Position des Balls
				pos.getY() + (Constants.BALL_DIAMETER / 2)));		//y-Position des Balls
		direction.rescale();	//Geschwindigkeit des Balls wird normalisiert
	}
	
	public boolean hitsStone() {
		
		return true;
	}
	
	/**
	 * Verschiebt bei Aufruf aktuelle Position des Ball um dx und dy.
	 */
	public void updatePosition() {
		this.pos.setPos (
			this.pos.getX() + this.direction.getDX(),	//Verschiebung auf x-Achse
			this.pos.getY() + this.direction.getDY());	//Verschiebung auf y-Achse
	}
	
	//getter fuer die Position des Balls
	public Position getPosition() {
		return this.pos;
	}
	
	//getter fuer die Richtung des Balls
	public Vector2D getDirection() {
		return this.direction;
	}
}
