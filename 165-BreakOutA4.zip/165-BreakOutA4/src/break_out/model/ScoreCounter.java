package break_out.model;

import java.awt.Color;

import break_out.Constants;

/**
 * Klasse ScoreCounter kontrolliert das Verhalten des score counters
 * @author Stefan Scheunemann 674685
 * @author Eric Neuwald 675477
 * Gruppe 165
 */

public class ScoreCounter {
	
	/**
	 * Startwert des Scores, sehe hoher Score moeglich
	 */
	int score = 0;
	
	/**
	 * Farbe, in der der Score auf Spielfeld angezeigt wird
	 */
	Color color = new Color(0, 0, 153);
	
	/**
	 * Position des Scores, der auf dem Spielfeld ausgegeben wird, liegt am unteren linken Spielfeldrand
	 */
	private Position position = new Position(45, (int)Constants.SCREEN_HEIGHT - 30);
	
	/**
	 * Methode zum veraendern des Scores, sobald dieser veraendert werden soll
	 * @param score neuer Score in int
	 */
	public ScoreCounter(int score) {
		this.score = score;
	}
	
	/**
	 * Methode zum erhoehen des Scores um einen Wert, alter Wert von Score wird erhoeht
	 * @param points zu addierende Punkte zu score
	 */
	public void addPoints(int points) {
		score = score + points;
	}
	
	/**
	 * gibt Position des Balls zurueck
	 * @return position
	 */
	public Position getPosition() {
		return this.position;
	}
	
	/**
	 * Gibt die Farbe des Score auf dem Spielfeld zurueck
	 * @return color
	 */
	public Color getColor() {
		return this.color;
	}
	
	/**
	 * Gibt den aktuellen Wert von Score zurueck
	 * @return score
	 */
	public int getScore() {
		return this.score;
	}
}