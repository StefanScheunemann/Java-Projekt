package break_out.model;

import javax.sound.midi.ControllerEventListener;

import break_out.Constants;

/**
 * Klasse Paddle kontrolliert das Verhalten des Paddle
 * @author Stefan Scheunemann 674685
 * @author Eric Neuwald 675477
 * Gruppe 165
 */

public class Paddle {
	
	/**
	 * Position des Paddle
	 */
	private Position pos;
	
	/**
	 * Breite des Paddle
	 */
	private double width = Constants.PADDLE_WIDTH;
	
	/**
	 * Hoehe des Paddle
	 */
	private double height = Constants.PADDLE_HEIGHT;
	
	/**
	 * Bewegungsrichtung des Paddle
	 */
	private int paddleDX;
	
	/**
	 * Startposition des Paddle
	 * Von den Konstanten der Breite und Hoehe des Spielfeldes muss Breite und Hoehe des Paddle abgezogen weden,
	 * da das Paddle sonst genau unter der Mitte des Spielfeldes liegt
	 */
	public Paddle() {		
		this.pos = new Position (
			Constants.SCREEN_WIDTH / 2 - getWidth() / 2,
			Constants.SCREEN_HEIGHT - getHeight());
	}
	
	/**
	 * beim Aufruf von updatePosition wird ueberpueft, ob die Position des Paddle verandert werden muss,
	 * wenn der Wert von paddleDX -1 oder 1 ist wird die Position auf der x-Achse um den Wert der Konstante DX_MOVEMENT, welche die Geschwindigkeit des Paddle kontrolliert, veraendert.
	 * Bei paddleDX = -1 wird das Paddle nach links verschoben, bei 1 nach rechts,
	 * ist der Wert von paddleDX 0 findet keine Aenderung der Position des Paddle statt, es wird die alte Position verwendet
	 */
	public void updatePosition() {
		if(paddleDX == -1 && this.pos.getX() >= Constants.DX_MOVEMENT) {		//wenn paddleDX -1 und es nicht am Bildschirmrand ist
			this.pos.setPos(this.getPosition().getX() - Constants.DX_MOVEMENT,	//Postion auf x-Achse wird um Konstante DX_Movement verschoben
				this.getPosition().getY());			//y-Position bleibt unveraendert
		}
		else if(paddleDX == 1 && this.pos.getX() <= Constants.SCREEN_WIDTH - Constants.PADDLE_WIDTH - Constants.DX_MOVEMENT) { //wenn paddleDX 1 und es nicht am Bildschirmrand ist
			this.pos.setPos(this.getPosition().getX() + Constants.DX_MOVEMENT,	//Postion auf x-Achse wird um Konstante DX_Movement verschoben
					this.getPosition().getY());		//y-Position bleibt unveraendert
		}
		else if(paddleDX == 0) {		//wenn keine Taste gedrueckt wird, steht das Paddle
			this.pos.setPos(this.getPosition().getX(),	//x-Position bleibt unveraendert
					this.getPosition().getY());			//y-Position bleibt unveraeaedert
		}
	}
	
	/**
	 * gibt Position des Paddle zurueck
	 * @return position
	 */
	public Position getPosition() {
		return this.pos;
	}
	
	/**
	 * gibt Breite des Paddle zurueck
	 * @return width
	 */
	public double getWidth() {
		return this.width;
	}
	
	/**
	 * gibt Hoehe des Paddle zurueck
	 * @return height
	 */
	public double getHeight() {
		return this.height;
	}
	
	/**
	 * gibt Bewegungsrichtung des Paddle zurueck
	 * @return paddleDX
	 */
	public int getPaddleDX() {
		return this.paddleDX;
	}
	
	/**
	 * setzt Bewegungsrichtung des Paddle
	 * @param paddleDX Bewegungsrichtung des Paddle
	 */
	public void setPaddleDX(int paddleDX) {
		this.paddleDX = paddleDX;
	}
}