package break_out.model;

import break_out.controller.JSONReader;
import java.awt.Color;
import java.awt.Rectangle;
import break_out.Constants;

/**
 * Klasse Paddle kontrolliert das Verhalten des Paddle
 * @author Stefan Scheunemann 674685
 * @author Eric Neuwald 675477
 * Gruppe 165
 */

public class Stone {
	
	/**
	 * Typ des Steins
	 */
	private int type = 0;
	
	/**
	 * Farbe des Steins
	 */
    private Color color = new Color(255, 135, 0);
    
    /**
     * Position des Steins mit x und y
     */
    private Position position;
    
    /**
     * Zustand des Steins
     */
    private boolean state = false;
    
    /**
     * Breite und Hoehe des Steins
     */
    private double stone_width = Constants.SCREEN_WIDTH / Constants.SQUARES_X - 3;
    private double stone_height = Constants.SCREEN_HEIGHT / Constants.SQUARES_Y - 3;
    
    /**
     * Rechteck um den Stein
     */
    private Rectangle rectangle;
    
    /**
     * Position des Steins im Raster wird erzeugt
     * Es wird ein Rechteck um den Stein erzeugt
     * @param gridPosX X-Koordinate des Steins wird gesetzt
     * @param gridPosY Y-Koordinate des Steins wird gesetzt
     */
    public Stone(int gridPosX, int gridPosY) {
        setPositionFromGridCoords(gridPosX, gridPosY);
        this.rectangle = new Rectangle((int)position.getX(),
        		(int)position.getY(),
        		(int)stone_width,
        		(int)stone_height);
    }
    
    /**
     * X- und Y-Position des Steins werden errechnet, indem die Spalte / Zeile des Steins mit Breite / Hoehe eines Feldes multiplziert wird
     * @param gridPosX X-Koordinate des Steins wird errechnet
     * @param gridPosY Y-Koordinate des Steins wird errechnet
     */
    private void setPositionFromGridCoords(int gridPosX, int gridPosY) {
        position = new Position(
                (Constants.SCREEN_WIDTH/Constants.SQUARES_X) * (gridPosX) + 2,
                (Constants.SCREEN_HEIGHT/Constants.SQUARES_Y) * (gridPosY) + 2);
    }
       
    /**
     * Zustand eines Steins wird von false auf true geaendert
     */
    public void deleteStone() {
    	state = true;    	
    }
      
    /**
     * Status / Zustand des Steins wird zurueckgegeben
     * @return state
     */
    public boolean getState() {
    	return this.state;
    }    
    /**
     * Breite eines Steins wird zuruckgegeben
     * @return width eines Steins
     */
    public double getStoneWidth() {
    	return stone_width;
    }
    
    /**
     * Hoehe eines Steins wird zurueckgegeben
     * @return heigtht eines Steins
     */
    public double getStoneHeight() {
    	return stone_height;
    }
    
    /**
     * Farbe des Steins wird zurueckgegeben
     * @return color des Steins
     */
    public Color getColor() {
    	return color;
    }
    
    /**
     * Position eines Steins wird zurueckgegeben
     * @return position des Steins
     */
    public Position getPosition() {
    	return position;
    }
    
    /**
     * Rechteck um den Stein wird zurueckgegeben
     * @return rectangle um Stein
     */
    public Rectangle getRectangle() {
    	return rectangle;
    }
}