package break_out.model;

import break_out.controller.JSONReader;

import java.awt.Color;

import break_out.Constants;

/**public class Stone {
	
	boolean zustand;
	double posX;
	double posY;
	
	JSONReader reader = new JSONReader(null);
	
	public int [][]stone = reader.getStones2DArray();
	
	int stone_width = ((int)Constants.SCREEN_WIDTH / Constants.SQUARES_X);
	int stone_height = ((int)Constants.SCREEN_HEIGHT / Constants.SQUARES_Y);
	
	public Stone(boolean zustand, double posX, double posY, int stone_width, int stone_height) {
		this.zustand = zustand;
		this.posX = posX;
		this.posY = posY;
		this.stone_width = stone_width;
		this.stone_height = stone_height;
	}
	
	Stone[][] steinMatrix = new Stone[Constants.SQUARES_X][Constants.SQUARES_Y];
	//Stone[][] steinMatrix = new Stone[Constants.SQUARES_X][Constants.SQUARES_Y](zustand, posX, posX, stone_height, stone_height);
	
	public Stone[][] getSteinMatrix2D() {
	
    for ( int zeile = 0; zeile < Constants.SQUARES_X; zeile++ )
    {
      for ( int spalte = 0; spalte < Constants.SQUARES_Y; spalte++ )
      
      if(stone[zeile][spalte] == 1) {
    	  steinMatrix[zeile][spalte] = new Stone(zustand = true,
    			  spalte * stone_width,
    			  zeile * stone_height,
    			  stone_width,
    			  stone_height);
      		}
      else {
    	  steinMatrix[zeile][spalte] = new Stone(zustand = false,
    			  spalte * stone_width,
    			  zeile * stone_height,
    			  stone_width,
    			  stone_height);
      }
    	}
	return steinMatrix;
	}

	
	public boolean getZustand() {
		return zustand;
    }
	
	public double getPosX() {
		return posX;
    }
	
	public double getPosY() {
		return posY;
    }
	
	public int getWidth() {
		return stone_width;
    }
	
	public int getHeight() {
		return stone_height;
    }
}	*/

public class Stone {
	
	//Unterschiedliche Arten von Steinen
	private int type = 0;
	
	//zufaellige Farbe des Steins
    private Color color = new Color(181, 240, 180, 150+ (int)(Math.random()*105));
    
    //Position fuer Stein
    private Position position;
    
    //Wenn Stein existiert, ist zustand false
    private boolean zustand = false;
    		
    private double stone_width = Constants.SCREEN_WIDTH / Constants.SQUARES_X;
    
    private double stone_height = Constants.SCREEN_HEIGHT / Constants.SQUARES_Y;
    
    //x und y Posistion des Stein in Grid
    public Stone(int gridPosX, int gridPosY) {
        setPositionFromGridCoords(gridPosX, gridPosY);
    }
    
    //Position des Steins in Grid wird erzeugt
    private void setPositionFromGridCoords(int gridPosX, int gridPosY) {
        position = new Position(
                (Constants.SCREEN_WIDTH/Constants.SQUARES_X) * (gridPosX),
                (Constants.SCREEN_HEIGHT/Constants.SQUARES_Y) * (gridPosY));
    }
    
    public double getStoneWidth() {
    	return stone_width;
    }
    
    public double getStoneHeight() {
    	return stone_height;
    }
    
    public Color getColor() {
    	return color;
    }
    
    public Position getPosition() {
    	return position;
    }
}

