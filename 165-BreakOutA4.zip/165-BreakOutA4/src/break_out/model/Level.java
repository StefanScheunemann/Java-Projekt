package break_out.model;

import java.util.ArrayList;
import java.util.List;

import break_out.controller.JSONReader;

/**
 * This object contains information about the running game
 * 
 *@author dmlux
 *@author I. Schumacher
 *
 *modified by
 *@author Stefan Scheunemann 674685
 *@author Eric Neuwald 675477
 *@Gruppe 165
 */

public class Level extends Thread {
	

    /**
     * The game to which the level belongs 
     */
    private Game game;
	 
    /**
   	 * The number of the level
   	 */
    private int levelnr;
       
    /**
     * Ball wird in Level benoetigt
     */
    private Ball ball;
    
    /**
     * Paddle wird in Level benoetigt
     */
    private Paddle paddle;
    
    /**
     * Stone wird in Level benoetigt
     */
    private Stone stone;
    
    /**
     * ScoreCounter wird in Level benoetigt
     */
    private ScoreCounter scoreCounter;
    
    /**
     * ArrayList, in der die Steine als Objekte abgelegt werden
     */
    private ArrayList<ArrayList<Stone>> levelStones = new ArrayList<>();
    
    
    /**
     * Flag that shows if the ball was started
     * Ball steht Anfangs still
     */
    private boolean ballWasStarted = false;

        
    /**
     * Der Konstruktor instanziiert einen neuen Level:
     * @param game Das zugehoerige Game-Objekt
     * @param levelnr Die Nummer des zu instanziierenden Levels
     * @param scoreCounter Haelt die Anzahl der erzielten Punkte
     * @param ball Position und Veraenderungen des Balls
     * @param paddle Instantziierung des Paddles, welches auf dem Spielfeld liegt
     */
    public Level(Game game, int levelnr, int score) {
    	this.game = game;
    	this.levelnr = levelnr;
    	this.scoreCounter = new ScoreCounter(score);
        loadLevelData(levelnr);
        this.ball = new Ball();
        this.paddle = new Paddle();
    }

    
    /**
     * Setzt ballWasStarted auf true, d.h. der Ball "startet", 
     * weil so die bedingten Anweisungen in der while-Schleife der run-Methode ausgefuehrt werden.
     */
    public void startBall() {
        ballWasStarted = true;
    }

    /**
     * Setzt ballWasStarted auf false, d.h. der Ball "pausiert", weil so die bedingten Anweisungen in der while-Schleife 
     * der run-Methode nicht ausgefuehrt werden.
     */
    public void stopBall() {
        ballWasStarted = false;
    }
    
    /**
     * Liefert den booleschen Wert der Variablen ballWasStarted
     * @return ballWasStarted True, wenn sich der Ball bewegt, sonst false
     */
    public boolean ballWasStarted() {
        return ballWasStarted;
    }
    
    /**
     * Methode wird verwendet, um auf das Objekt Ball zugreifen zu koennen, wird in der Klasse Field benoetigt
     * @return ball
     */
    public Ball getBall() {
    	return this.ball;
    }
    
    /**
     * getter fuer Paddle, wird in der Klasse Field benoetigt
     * @return paddle
     */
    public Paddle getPaddle() {
    	return this.paddle;
    }
        
    /**
     * getter fuer LevelStones, wird benoetigt, um auf Steinliste zugreifen zu koennen
     * @return levelStones
     */
    public ArrayList<ArrayList<Stone>> getLevelStones() {
        return levelStones;
    }
        
    /**
     * getter fuer ScoreCounter, wird benoetigt, um den Punktestand zu nutzen
     * @return scoreCounter
     */
    public ScoreCounter getScoreCounter() {
		return scoreCounter;
	}


	/**
     * Diese Methode enthaelt die Threadlogik, d.h. hier wird festgelegt, was im Thread ablaeuft.
     */
    public void run() {	
    	
    	game.notifyObservers();
    		
    	// Endlosschleife fuer den Ablauf
    	while (true) {
    		// wenn ballWasStarted wahr ist (d.h. der Ball soll sich bewegen)
	        if (ballWasStarted) {
	            
	        	//Aufruf der Methode reactOnBorder aus Ball, prueft auf Wandberuehrung
	        	ball.reactOnBorder();
	        	
	        	//Prueft, ob Ball einen Stein beruehrt, falls die eintritt, prallt der Ball am Stein ab, der Score wird um 1 erhoeht und der Stein wird entfernt
                if(ball.hitsStone(levelStones)) {
                    Stone stone = ball.getLastHitStone();	//Listenposition des zuletzt getroffenen Stein wird zwischengespeichert
                    ball.reflectOnStone(stone);		//Methode fuer das Abprallen des Balls an Stein wird aufgerufen
                    scoreCounter.addPoints(1);		//Score wird um 1 erhoeht
                    stone.deleteStone();            //Methode fuer das Loeschen von Steinen wird aufgerufen, zuletzt getroffener Stein wird von Spielfeld entfernt
                }
	        	
	        	//Abprallen des Balls am Paddle
	        	if(this.ball.hitsPaddle(paddle)) {	//Test auf Beruehrung des Balls mit Paddle
	        		this.ball.reflectOnPaddle(paddle);	//Methode zum ablenken de Balls wird aufgerufen
	        	}
	        	
	        	//Aufruf der Methode Update Position aus Ball, aktualisiert Position des Balls
	        	ball.updatePosition();
	        	
	        	//Aufruf der Methode Update Position aus Paddle, aktualisiert Position des Paddle
	        	paddle.updatePosition();
	                               
	            // Das als Observer angemeldete View-Objekt wird informiert, damit ein Neuzeichnen (repaint)
	        	// des Spielfeldes vorgenommen wird.
	            game.notifyObservers();    
	                
	        }
	        // Der Thread pausiert kurz
	        try {
	            Thread.sleep(4);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
    	}   
    }
    
    
    /**
    * Zugriff auf die der Levelnummer zugeordnete JSON-Datei
    * Es wird der Pfad der Datei generiert, aus der die Steinmatrix erstellt wird.
    * Um die Steine in Form von Objekten zu erstellen wird die StoneList verwendet, mit einer Schleife wird die JSON Liste ausgelesen.
    * Fuer jedes Feld, beim dem in der JSON Datei eine 1 eingetragen ist wird ein Stein der neu erstellten stoneList hinzugefuegt.
    * Sobald die gesamte JSON Datei durchlaufen wurde und alle Steine in der stoneList erstellt wurden wird stoneList der uebergeordneten Liste levelStones zugeordnet.
    * @param levelnr Die Nummer fuer die Level.json Datei
    */
    private void loadLevelData(int levelnr) {
        JSONReader reader = new JSONReader("res/Level" + levelnr + ".json");

        int gridPosX, gridPosY = 0;

        //Auslesen der gesamten Liste
        for(List<Long> dataStoneList : reader.getStonesListOfLists()) {
            //eine neue Liste wird erstellt, in der die Steine abgelegt werden
            ArrayList<Stone> stoneList = new ArrayList<>();

            gridPosX = 0;

            for(Long dataStone : dataStoneList) {
                //bei einem Feld in der JSON Datei, welches als Wert 1 besitzt, wird ein neues Stein-Objekt erzeugt,
            	//diesem wird auch direkt eine Position zugewiesen
                if(dataStone == 1) {
                    stoneList.add(new Stone(gridPosX, gridPosY));                    //System.out.println(gridPosX);
                }
                gridPosX++;
            }
            gridPosY++;

            //neu erstellte Liste wird der uebergeordneten Steinliste in Level zugeordnet
            levelStones.add(stoneList);
        }
    }    
}	
