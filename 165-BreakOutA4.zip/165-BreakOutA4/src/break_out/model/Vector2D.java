package break_out.model;

/**
 * Fuer die rescale Methode werden die Konstanten aus der Klasse Constants benoetigt,
 * weswegen diese hier importiert werden
 */
import break_out.Constants;


/**
 * Klasse Vector2D wird benoetigt, um Vektoren aufzurufen und zu normalisieren
 *@author Stefan Scheunemann 674685
 *@author Eric Neuwald 675477
 *Gruppe 165
 */

public class Vector2D {		
	
	/**
	 * dx stellt Bewegungsrichtung auf x-Achse dar
	 */
	private double dx;
	
	/**
	 * dy stellt Bewegungsrichtung auf y-Achse dar
	 */
	private double dy;
	

	/**
	 * Konstruktor,der Paramterwerte fuer zwei Positionobjekte erwartet
	 * Der erste Wert gibt den Ausgangspunkt, der zweite den Zielpunk des
	 * zu erstellenden Verktors an
	 * @param source Der Ausgangspunkt
	 * @param target Der Zielpunkt
	 */
	public Vector2D(Position source, Position target) {	
		this.dx = target.getX() - source.getX();
		this.dy = target.getY() - source.getY();
	}
	
	/**
	 * 	Zweiter Konstruktor, enthaelt die Variablen dx und dy vom Typ double,
	 *  die an anderen Stellen benoetigt werden
	 * @param dx kann frei gesetzt werden
	 * @param dy kann frei gesetzt werden
	 */
	public Vector2D(double dx, double dy) {
		this.dx = dx;
		this.dy = dy;
	}
	
	
	/**
	 * Die rescale Methode wird verwendet, um zuerst den Richtungsvektor zu normieren und
	 * dann mit der Konstante BALL_SPEED zu multiplizieren, wodurch die Geschwindigkeit des
	 * Balls final bestimmt wird
	 */
	public void rescale() {

		/**
		 * Normierung findet durch Satz des Pythagoras statt
		 * dx und dy werden in der Klasse Level bestimmt
		 * c = sqrt(a^2 + b^2)
		 */
		double richtungsvektor = Math.sqrt((this.dx * this.dx) + (this.dy * this.dy));
		
		/**
		 * Wert von dx und dy werden durch den Wert von "richtungsvektor" geteilt, um die Werte
		 * zu normeiren und dann mit BALL_SPEED multipliziert.
		 */
		this.dx = (this.dx / richtungsvektor) * Constants.BALL_SPEED;
		this.dy = (this.dy / richtungsvektor) * Constants.BALL_SPEED;		
		
	}
	
	/**
	 * Getter fuer dx
	 * @return dx
	 */
	public double getDX() {
		return dx;
	}
	
	/**
	 * Getter fuer dy
	 * @return dy
	 */
	public double getDY() {
		return dy;
	}
	
	/**
	 * Setter fuer dx
	 * @param dx = neuer Wert fuer dx
	 */
	public void setDX(double dx) {
		this.dx = dx;
	}
	
	/**
	 * Setter fuer dy
	 * @param dy = neuer Wert fuer dy
	 */
	public void setDY(double dy) {
		this.dy = dy;
	}
}