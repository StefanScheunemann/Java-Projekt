package break_out.model;

//Konstanten werden f�r Breite und H�he des Spielfeldes und des Balls ben�tigt
import break_out.Constants;

/**
 * Klasse Ball kontrolliert das Verhalten des Balls
 * @author Stefan Scheunemann 675686
 * @author Eric Neuwald 675477
 * Gruppe 165
 */

public class Ball {
	
	//Variablendeklaration
	private Position pos;	
	private Vector2D direction;
	
	
	public Ball() {
		
		//Initialisierung der Instanzvariablen
		this.pos = new Position(
				Constants.SCREEN_WIDTH / 2 - Constants.BALL_DIAMETER / 2,
				Constants.SCREEN_HEIGHT - Constants.BALL_DIAMETER - Constants.PADDLE_HEIGHT);
		
		this.direction = new Vector2D(5, -5);
		this.direction.rescale();
				
	}
	
	public void reactOnBorder( ) {
        if(pos.getX() <= 0) {			//wenn Position des Balls auf der x-Achse <= 0 ist, wird die Wand beruehrt und der Ball soll abprallen
        	double dx = -direction.getDX();		//die Richtung des Balls auf der x-Achse wird invertiert
        	direction.setDX(dx);	//der invertierte Wert f�r dx wird in der Klasse Vector2D gespeichert
        }
        
        else if(pos.getX() >= Constants.SCREEN_WIDTH - Constants.BALL_DIAMETER) {		//wenn Position des Balls auf der x-Achse <= der Breite des Felds ist, wird die Wand ber�hrt und der Ball soll abprallen
        	double dx = -direction.getDX();		//die Richtung des Balls auf der x-Achse wird invertiert
        	direction.setDX(dx);	//der invertierte Wert f�r dx wird in der Klasse Vector2D gespeichert
        }
        
    	          
        else if(pos.getY() <= 0) {		//wenn Position des Balls auf der y-Achse <= 0 ist, wird die Wand beruehrt und der Ball soll abprallen
        	double dy = -direction.getDY();		//die Richtung des Balls auf der x-Achse wird invertiert
        	direction.setDY(dy);	//der invertierte Wert f�r dy wird in der Klasse Vector2D gespeichert
        }
        
        else if(pos.getY() >= Constants.SCREEN_HEIGHT - Constants.BALL_DIAMETER) {		//wenn Position des Balls auf der y-Achse <= der H�he des Felds ist, wird die Wand ber�hrt und der Ball soll abprallen
        	double dy =  -direction.getDY();	//die Richtung des Balls auf der x-Achse wird invertiert
        	direction.setDY(dy);	//der invertierte Wert f�r dy wird in der Klasse Vector2D gespeichert
        }
	}
	
	//Position des Balls wird bei Aufruf der Methode verschoben
	public void updatePosition() {
		this.pos.setPos (
			this.pos.getX() + this.direction.getDX(),	//Verschiebung auf x-Achse
			this.pos.getY() + this.direction.getDY());	//Verschiebung auf y-Achse
	}
	
	//getter f�r die Position des Balls
	public Position getPosition() {
		return this.pos;
	}
	
	//getter f�r die Richtung des Balls
	public Vector2D getDirection() {
		return this.direction;
	}
}
