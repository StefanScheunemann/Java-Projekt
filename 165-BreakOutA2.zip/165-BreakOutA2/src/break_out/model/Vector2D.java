/**Vector2D
*@author Stefan Scheunemann 674685
*@author Eric Neuwald 
*@Gruppe 165
*/


package break_out.model;

/**
 * F�r die rescale Methode werden die Konstanten aus der Klasse Constants ben�tigt,
 * weswegen diese hier importiert werden
 */
import break_out.Constants;


public class Vector2D {		//Klasse Vektor2D
	
	//Variablendeklaration
	private double dx = 1;
	private double dy = 1;

	/**
	 * Erster Konstruktor, bleibt leer
	 */
	public Vector2D() {		
	}
	
	/**
	 * 	Zweiter Konstruktor, enth�lt die Variablen dx und dy vom Typ double,
	 *  die an anderen Stellen ben�tigt werden
	 * @param dx kann frei gesetzt werden
	 * @param dy kann frei gesetzt werden
	 */
	public Vector2D(double dx, double dy) {
		this.dx = dx;
		this.dy = dy;
	}
	
	
	/**
	 * Die rescale Methode wird verwendet, um zuerst den Richtungsvektor zu normieren und
	 * dann mit der Konstante BALL_SPEED zu multiplizieren, wodurch die Geschwindigkeit des
	 * Balls final bestimmt wird
	 */
	public void rescale() {

		/**
		 * Normierung findet durch Satz des Pythagoras statt
		 * dx und dy werden in der Klasse Level bestimmt
		 * c = sqrt(a^2 + b^2)
		 */
		double richtungsvektor = Math.sqrt((this.dx * this.dx) + (this.dy * this.dy));
		
		/**
		 * Wert von dx und dy werden durch den Wert von "richtungsvektor" geteilt, um die Werte
		 * zu normeiren und dann mit BALL_SPEED multipliziert.
		 */
		this.dx = (this.dx / richtungsvektor) * Constants.BALL_SPEED;
		this.dy = (this.dy / richtungsvektor) * Constants.BALL_SPEED;		
		
	}
	
	/**
	 * Getter f�r dx
	 * @return dx
	 */
	public double getDX() {
		return dx;
	}
	
	/**
	 * Getter f�r dy
	 * @return dy
	 */
	public double getDY() {
		return dy;
	}
	
	/**
	 * Setter f�r dx
	 * @param dx = neuer Wert f�r dx
	 */
	public void setDX(double dx) {
		this.dx = dx;
	}
	
	/**
	 * Setter f�r dy
	 * @param dy = neuer Wert f�r dy
	 */
	public void setDY(double dy) {
		this.dy = dy;
	}
}
