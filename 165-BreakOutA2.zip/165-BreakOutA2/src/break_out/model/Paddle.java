package break_out.model;

//Import von Konstanten, f�r Position benoetigt
import break_out.Constants;

/**
 * Klasse Paddle kontrolliert das Verhalten des Paddle
 * @author Stefan Scheunemann 674685
 * @author Eric Neuwald 675477
 * Gruppe 165
 */

public class Paddle {
	
	//Instanzvariable f�r Position des Paddle
	private Position pos;
	
	//Breite des Paddle
	private double width = Constants.PADDLE_WIDTH;
	
	//Hoehe des Paddle
	private double height = Constants.PADDLE_HEIGHT;
	
	/**
	 * Startposition des Paddle
	 * Von den Konstanten der Breite und Hoehe des Spielfeldes muss Breite und Hoehe des Paddle abgezogen weden,
	 * da das Paddle sonst genau unter der Mitte des Spielfeldes liegt
	 */
	public Paddle() {		
		this.pos = new Position (
			Constants.SCREEN_WIDTH / 2 - getWidth() / 2,
			Constants.SCREEN_HEIGHT - getHeight());
	}
	
	//getter f�r Position des Padlle
	public Position getPosition() {
		return this.pos;
	}
	
	//getter f�r die Breite des Paddle
	public double getWidth() {
		return this.width;
	}
	
	//getter f�r die Hoehe des Paddle
	public double getHeight() {
		return this.height;
	}
}
